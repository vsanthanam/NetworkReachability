//
//  ReachabilityApp.swift
//  Reachability
//
//  Created by Varun Santhanam on 7/10/22.
//

import SwiftUI

@main
struct ReachabilityApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
